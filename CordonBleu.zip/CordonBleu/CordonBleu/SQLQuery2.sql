﻿SET IDENTITY_INSERT Products ON;

INSERT INTO Products (Id, Name, Price, Category, ImagePath, Description)
VALUES
(25000, 'Baileys', 25000, 'Coffee', 'https://example.com/images/baileys.jpg', 'Coffee Based with Baileys'),
(25001, 'Irish Coffee', 25000, 'Coffee', 'https://example.com/images/irish_coffee.jpg', 'Authentic Coffee with Irish Whiskey'),
(25002, 'Aren Latte', 22000, 'Coffee', 'https://example.com/images/aren_latte.jpg', 'Coffee Latte with Signature Aren'),
(25003, 'Dirty Matcha', 24000, 'Coffee', 'https://example.com/images/dirty_matcha.jpg', 'Matcha with Coffee'),
(25004, 'Jack Frost Mocktails', 27000, 'Mocktails', 'https://example.com/images/jack_frost_mocktails.jpg', 'Mocktails with Blue Curacao and Coconut Cream'),
(25005, 'Pina Colada', 30000, 'Mocktails', 'https://example.com/images/pina_colada.jpg', 'Pineapple and Coconut Cream'),
(25006, 'Hana Verde', 30000, 'Mocktails', 'https://example.com/images/hana_verde.jpg', 'Matcha blended with Mocktails');



SET IDENTITY_INSERT Products OFF;
