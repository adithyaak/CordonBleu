﻿using System.ComponentModel.DataAnnotations;

namespace CordonBleu.Models
{
    public class Product
    {
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string Name { get; set; }

        [Required]
        [StringLength(50)]
        public string Category { get; set; }

        [Required]
        [Range(0, double.MaxValue)]
        public decimal Price { get; set; }

        // ✅ Properti ini wajib agar controller dan view tidak error
        [Display(Name = "Product Image")]
        public string? ImagePath { get; set; }

        public string? Description { get; set; } = "";
    }
}
