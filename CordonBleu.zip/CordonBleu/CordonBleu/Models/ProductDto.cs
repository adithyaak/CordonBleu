﻿using System.ComponentModel.DataAnnotations;

namespace CordonBleu.Models
{
    public class ProductDto
    {
        [Required, MaxLength(100)]
        public string Name { get; set; } = "";

        [Required]
        public decimal Price { get; set; }

        [Required, MaxLength(100)]
        public string Category { get; set; } = "";

        public string Description { get; set; } = "";

        [MaxLength(500)]
        public string ImagePath { get; set; }  // ✅ konsisten dengan Product
    }
}
